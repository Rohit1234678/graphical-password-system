# Graphical-Password-Authentication-System

This is a web based authentication system which allows users to sign up and log in using a different model. People usually remember pictures better than words and text passwords are very easy to hack. Therefore, graphical passwords provide better security than traditional text passwords. This system combines graphical and text passwords achieving the best of both. A user can select images and their grid points and use them as the graphical password.



This project was developed using HTML, PHP, JavaScript, JQuery, CSS and MySQL.
